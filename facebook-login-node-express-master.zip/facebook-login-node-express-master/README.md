facebook-login-node-express
===========================

Facebook login Script using Node and Express

Download the code and run <code>npm install</code> then <code>node app.js</code>

Access the app at localhost:3000.

Tutorial link : http://wp.me/p4ISPV-7w

